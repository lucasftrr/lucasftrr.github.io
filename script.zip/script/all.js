// SCRIPT EVENT JS

let MousePosition = {x:undefined, y:undefined};

window.addEventListener('mousemove', (event) => {
  MousePosition = { x: event.clientX, y: event.clientY };
  
  if(MousePosition.x === 0 && MousePosition.y === 0) alert("Tu as découvert le secret !");

  document.body.style = "background-image: radial-gradient(circle farthest-side at "+MousePosition.x+"px "+MousePosition.y+"px, #010d50 1%, #000629 50%);"
});


// MODAL

document.getElementById("uncharted").addEventListener("click", uncharted);
document.getElementsByClassName("modal-close")[0].addEventListener("click", close);


function uncharted() {
  const modals = document.getElementsByClassName("modals");
  modals[0].style.display = "flex";

  document.getElementById("modal-uncharted").style.display = "unset";
}


function close() {
  const modals = document.getElementsByClassName("modals");
  modals[0].style.display = "none";
}